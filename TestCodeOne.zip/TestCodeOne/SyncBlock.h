#pragma once

void SyncBlockServer();

void Handler(int);
