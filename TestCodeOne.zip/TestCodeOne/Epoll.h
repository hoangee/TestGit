#pragma once

void EpollServer();

