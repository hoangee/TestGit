﻿#include "SyncBlock.h"
#include "SyncNoBlock.h"
#include <signal.h>
#include "ThreadPool.h"
#include "Epoll.h"
#include "Nlibevent.h"

int main()
{
	//忽略管道信息， 防止客户端请求服务端关闭后导致服务端死掉
	if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
	{
		return 1;
	}
	//ThreadPool::Ptr threadPool = ThreadPool::Instance();
	//threadPool->Init(ThreadPoolConfig{ 100,  1024, 1024, std::chrono::seconds(1) });
	//threadPool->Start();

	//SyncNoBlockServer();

	//SyncBlockServer();

	//EpollServer();

	LibEventServer();

	return 0;
}